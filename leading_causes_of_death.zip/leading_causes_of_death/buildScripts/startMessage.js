//var chalk = require('chalk');
import chalk from 'chalk';

console.log(chalk.green("Starting App in Dev Mode..."));
